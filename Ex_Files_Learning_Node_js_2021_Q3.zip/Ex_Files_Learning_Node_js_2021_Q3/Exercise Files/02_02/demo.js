var _ = require('lodash')

console.log(_.random(1,10))