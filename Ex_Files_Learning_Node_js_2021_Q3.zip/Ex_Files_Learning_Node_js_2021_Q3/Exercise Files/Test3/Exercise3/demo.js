const { random } = require('lodash');
var _  = require('lodash');

console.log(_.random(1, 15));