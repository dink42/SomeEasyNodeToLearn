var fs = require('fs');

var data = {
    name: 'bob'
}

fs.writeFile('data.json', JSON.stringify(data), (err) => {
    console.log('Write was finnished', err)
});